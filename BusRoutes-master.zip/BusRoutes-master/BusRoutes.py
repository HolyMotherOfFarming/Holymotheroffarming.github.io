print1 = "Bus 1"
print2 = "Bus 2"

print(print1)
print(print2)