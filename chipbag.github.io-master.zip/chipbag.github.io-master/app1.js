alert('Turn volume off/mute this tab if you do not want to hear the best music ever made, and hit "ok."');
alert('Please take a few moments to donate to our fine cause.')
prompt('How much will you donate?')
alert('not enough')
prompt('How much will you donate?')
alert('ok')